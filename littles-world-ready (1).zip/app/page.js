export default function HomePage() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Welcome to Little World!</h2>
      <p>Your 3D baby clothes showcase will appear here.</p>
    </div>
  );
}